import type { NavigationMenuItem } from "@nuxt/ui";
import { parseLinkQuery, stripQueryAndHash } from "./routePath";
import { isString } from "./type-check";

export const MENU_STATUS_TEXT_CLASSES: Record<MenuItemStatus, string> = {
  success: "text-success",
  warning: "text-warning",
  error: "text-error",
  neutral: "text-dimmed",
};

/** Status colors for the chip on a parent entry's leading icon. */
export const MENU_STATUS_CHIP_COLORS = {
  success: "success",
  warning: "warning",
  error: "error",
  neutral: "neutral",
} as const satisfies Record<MenuItemStatus, string>;

export const translateMenuItem = (
  item: NavigationMenuItem,
  processI18n: (value: string) => string,
): NavigationMenuItem => ({
  ...item,
  label: item.label ? processI18n(item.label) : undefined,
  children: item.children
    ? item.children.map((child) => translateMenuItem(child, processI18n))
    : undefined,
});

export const translateMenuItems = (
  items: NavigationMenuItem[][],
  processI18n: (value: string) => string,
): NavigationMenuItem[][] => {
  return items.map((group) =>
    group.map((item) => translateMenuItem(item, processI18n)),
  );
};

export const shouldExpandMenuItem = (
  item: NavigationMenuItem,
  matchedFullId: string | null,
): boolean => {
  if (!matchedFullId) return false;
  const dmsItem: DmsMenuItem = item;
  const fullId = dmsItem.fullId;
  if (!isString(fullId) || fullId === "") return false;
  return matchedFullId === fullId || matchedFullId.startsWith(`${fullId}.`);
};

const normalizeRoutePath = (path: string): string =>
  path.length > 1 && path.endsWith("/") ? path.slice(0, -1) : path;

const matchesRoutePrefix = (currentPath: string, to: string): boolean => {
  const target = normalizeRoutePath(to);
  const current = normalizeRoutePath(currentPath);
  if (target === "" || target === "/") return current === target;
  return current === target || current.startsWith(`${target}/`);
};

const resolveItemTarget = (
  to: NavigationMenuItem["to"],
): MenuItemTarget | null => {
  if (isString(to)) {
    return { path: stripQueryAndHash(to), query: parseLinkQuery(to) };
  }
  // oxlint-disable-next-line anti-slop/require-safety-comment-for-type-assertion -- Preserve the base's unchecked menu projection without widening its public string query contract to router query arrays.
  const target = to as MenuItemTarget | undefined;
  if (target && isString(target.path)) {
    return { path: target.path, query: target.query };
  }
  return null;
};

const hasQuery = (target: MenuItemTarget | null): boolean =>
  Object.keys(target?.query ?? {}).length > 0;

const queryMatches = (
  declared: MenuItemTarget["query"],
  currentQuery: MenuRouteState["query"],
): boolean => {
  if (!declared) return true;
  return Object.entries(declared).every(
    ([key, value]) => currentQuery[key] === value,
  );
};

/** Highlights a parent on sub-routes only when no descendant is active. */
export const isMenuItemActive = (
  item: NavigationMenuItem,
  matchedFullId: string | null,
  currentRoute: MenuRouteState,
  isDescendantActive = false,
): boolean => {
  const target = resolveItemTarget(item.to);
  if (!target) return false;
  if (!queryMatches(target.query, currentRoute.query)) return false;
  const matchesRoute =
    item.children?.length && isDescendantActive
      ? normalizeRoutePath(currentRoute.path) ===
        normalizeRoutePath(target.path)
      : matchesRoutePrefix(currentRoute.path, target.path);
  if (matchesRoute) return true;
  const dmsItem: DmsMenuItem = item;
  const fullId = dmsItem.fullId;
  return matchedFullId !== null && fullId === matchedFullId;
};

/**
 * Query entries and parents override native prefix highlighting. Plain leaves
 * keep the router's fallback for routes the DMS cannot string-match.
 */
const resolveActiveState = (
  item: NavigationMenuItem,
  isActive: boolean,
): Partial<Pick<NavigationMenuItem, "active">> => {
  if (isActive) {
    return { active: true };
  }
  return hasQuery(resolveItemTarget(item.to)) || item.children?.length
    ? { active: false }
    : {};
};

interface MenuRouteVerdict {
  item: NavigationMenuItem;
  holdsActive: boolean;
}

function judgeMenuRoute(
  item: NavigationMenuItem,
  matchedFullId: string | null,
  currentRoute: MenuRouteState,
): MenuRouteVerdict {
  const children = item.children?.map((child) =>
    judgeMenuRoute(child, matchedFullId, currentRoute),
  );
  const descendantActive =
    children?.some((child) => child.holdsActive) ?? false;
  const active = isMenuItemActive(
    item,
    matchedFullId,
    currentRoute,
    descendantActive,
  );
  const holdsActive = active || descendantActive;
  return {
    holdsActive,
    item: {
      ...item,
      ...resolveActiveState(item, active),
      defaultOpen: children?.length
        ? holdsActive || shouldExpandMenuItem(item, matchedFullId)
        : undefined,
      children: children?.map((child) => child.item),
    },
  };
}

/** Computes highlight and expansion together, from descendants to ancestors. */
export const applyMenuRouteState = (
  items: NavigationMenuItem[][],
  matchedFullId: string | null,
  currentRoute: MenuRouteState,
): NavigationMenuItem[][] => {
  return items.map((group) =>
    group.map((item) => judgeMenuRoute(item, matchedFullId, currentRoute).item),
  );
};

const collectExpandedIds = (items: NavigationMenuItem[]): string[] => {
  const ids: string[] = [];
  for (const item of items) {
    if (isString(item.id) && item.defaultOpen) {
      ids.push(item.id);
    }
    if (item.children) ids.push(...collectExpandedIds(item.children));
  }
  return ids;
};

/** Reads the expansion verdict for controlled accordions. */
export const collectOpenItemIds = (items: NavigationMenuItem[][]): string[] => {
  return items.flatMap((group) => collectExpandedIds(group));
};
